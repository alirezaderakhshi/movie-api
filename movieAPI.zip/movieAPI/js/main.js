var pageCounter;
var searchText="";
var movieCounter = 0;

var searchAll = function(){
  let element = document.getElementById("search");
  searchText = element.value;
  pageCounter=1;
  document.getElementById("movies").innerHTML = "";
  getMovies();
  element.value = "";
}

var searchByTitle = function(){
  let element = document.getElementById("title");
  searchText = element.value;
  document.getElementById("movies").innerHTML = "";
  pageCounter=1;
  getSingleMovie("title");
  element.value = "";
}

var searchById = function(){
  let element = document.getElementById("imdbID");
  searchText = element.value;
  document.getElementById("movies").innerHTML = "";
  pageCounter=1;
  getSingleMovie("imdbID");
  element.value = "";
}

var setSearchFormDiv = function(){
  document.getElementById("movies").innerHTML = "";
  document.getElementById("titleFormDiv").style.display = "none";
  document.getElementById("idFormDiv").style.display = "none";
  document.getElementById("searchFormDiv").style.display = "block";
  document.getElementById("setSearchBtn").style.display = "none";
  document.getElementById("setTitleBtn").style.display = "inline-block";
  document.getElementById("setIdBtn").style.display = "inline-block";
}

var setTitleFormDiv = function(){
  document.getElementById("movies").innerHTML = "";
  document.getElementById("searchFormDiv").style.display = "none";
  document.getElementById("idFormDiv").style.display = "none";
  document.getElementById("titleFormDiv").style.display = "block";
  document.getElementById("setTitleBtn").style.display = "none";
  document.getElementById("setSearchBtn").style.display = "inline-block";
  document.getElementById("setIdBtn").style.display = "inline-block";

}

var setIdFormDiv = function(){
  document.getElementById("movies").innerHTML = "";
  document.getElementById("searchFormDiv").style.display = "none";
  document.getElementById("titleFormDiv").style.display = "none";
  document.getElementById("idFormDiv").style.display = "block";
  document.getElementById("setIdBtn").style.display = "none";
  document.getElementById("setSearchBtn").style.display = "inline-block";
  document.getElementById("setTitleBtn").style.display = "inline-block";
}

async function getMovies(){
  try{
      let moviesElement = document.getElementById("movies");
      if(moviesElement.innerHTML == `<h6> No Content Found!...Try Again </h6>`){
        moviesElement.innerHTML = "";
      }
      let moreResultsBtn = document.getElementById("moreResultsBtn");
      if(typeof(moreResultsBtn) != undefined && moreResultsBtn != null){
        moreResultsBtn.remove();
        pageCounter+=1;
      }
      document.getElementById("search").value = "";
      if(searchText==undefined || searchText==""){
        return;
      }
      let response = await fetch(`http://www.omdbapi.com/?s=${searchText}&apikey=323721c4&page=${pageCounter}`);
      console.log("Response Status",response.statusText); 
      let json = await response.json();
      let movies = json.Search;
      if(movies === undefined && pageCounter!=1){
        return;
      }
      else if(movies === undefined && pageCounter==1){
        throw new Error();
      }
      console.log(movies);
      let output = "";
      movies.forEach(movie => {
        movieCounter++;
        output = `    <div id="whiteSpace">
                        <br/>
                      </div>
                      <div class="row">
                        <div class="col-md-4">
                          <img src="${movie.Poster}" class="thumbnail" id="img_${movieCounter}">
                        </div>
                        <div class="col-md-8">
                          <h2>${movie.Title}</h2>
                          <ul class="list-group">
                            <li class="list-group-item"><strong>Year: </strong> ${movie.Year}</li>
                            <li class="list-group-item"><strong>Type: </strong> ${movie.Type}</li>
                            <li class="list-group-item"><strong>IMDB ID: </strong> ${movie.imdbID}</li>
                          </ul>
                        </div>
                      </div>
                      <div class="row">
                        <div class="well">
                          <br/>
                          <a href="http://imdb.com/title/${movie.imdbID}" target="_blank" class="btn btn-primary">View IMDB</a>
                          <a href="index.html" class="btn btn-default">Go Back To Search</a>
                        </div>
                      </div>
                      <div id="whiteSpace">
                        <br/>
                      </div>
                      <hr>
                      `;
        document.getElementById("movies").innerHTML += output;
        if(movie.Poster === "N/A"){
          document.getElementById(`img_${movieCounter}`).setAttribute("src","css/ImageNotFound.png");
        }
      });
      
      document.getElementById("movies").innerHTML += `<button id="moreResultsBtn" onclick="getMovies()" class="btn btn-warning">Show More Results</button>`;

    }
    catch(error){
      console.error(error);
      document.getElementById("movies").innerHTML = `<h6> No Content Found!...Try Again </h6>`;
    }
}

async function getSingleMovie(idOrTitle){
  try{
      let moviesElement = document.getElementById("movies");
      if(moviesElement.innerHTML == `<h6> No Content Found!...Try Again </h6>`){
        moviesElement.innerHTML = "";
      }
      let response;
      if(idOrTitle == "imdbID"){
        document.getElementById("imdbID").value = "";
        if(searchText==undefined || searchText==""){
          return;
        }
        response = await fetch(`http://www.omdbapi.com/?i=${searchText}&apikey=323721c4`)
      }
      else if(idOrTitle == "title"){
        document.getElementById("title").value = "";
        if(searchText==undefined || searchText==""){
          return;
        }
        response = await fetch(`http://www.omdbapi.com/?t=${searchText}&apikey=323721c4`)
      }
      console.log("Response Status",response.statusText);
      let output = "";
      let movie = await response.json();
      if(movie.Title===undefined){
        throw new Error();
      }
      movieCounter++;
      output += `   <div id="whiteSpace">
                      <br/>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <img src="${movie.Poster}" class="thumbnail" id="img_${movieCounter}">
                      </div>
                      <div class="col-md-8">
                        <h2>${movie.Title}</h2>
                        <ul class="list-group">
                          <li class="list-group-item"><strong>Year: </strong> ${movie.Year}</li>
                          <li class="list-group-item"><strong>Type: </strong> ${movie.Type}</li>
                          <li class="list-group-item"><strong>Genre: </strong> ${movie.Genre}</li>
                          <li class="list-group-item"><strong>Released: </strong> ${movie.Released}</li>
                          <li class="list-group-item"><strong>Actors: </strong> ${movie.Actors}</li>
                          <li class="list-group-item"><strong>Director: </strong> ${movie.Director}</li>
                          <li class="list-group-item"><strong>Writer: </strong> ${movie.Writer}</li>
                          <li class="list-group-item"><strong>Awards: </strong> ${movie.Awards}</li>
                          <li class="list-group-item"><strong>Box Office: </strong> ${movie.BoxOffice}</li>
                          <li class="list-group-item"><strong>Country: </strong> ${movie.Country}</li>
                          <li class="list-group-item"><strong>DVD: </strong> ${movie.DVD}</li>
                          <li class="list-group-item"><strong>Language: </strong> ${movie.Language}</li>
                          <li class="list-group-item"><strong>Production: </strong> ${movie.Production}</li>
                          <li class="list-group-item"><strong>Rated:</strong> ${movie.Rated}</li>
                          <li class="list-group-item"><strong>IMDB Rating:</strong> ${movie.imdbRating}</li>
                          <li class="list-group-item"><strong>IMDB ID</strong> ${movie.imdbID}</li>
                          <li class="list-group-item"><strong>IMDB Votes: </strong> ${movie.imdbVotes}</li>
                        </ul>
                      </div>
                    </div>
                    <div class="row">
                      <div class="well">
                        <h3>Description</h3>
                        ${movie.Plot}
                        <hr>
                        <br/>
                        <a href="http://imdb.com/title/${movie.imdbID}" target="_blank" class="btn btn-primary">View IMDB</a>
                        <a href="index.html" class="btn btn-default">Go Back To Search</a>
                      </div>
                    </div>
                    <div id="whiteSpace">
                      <br/>
                    </div>
                    <hr>
                    `;
      if(movie.Poster === "N/A"){
          document.getElementById(`img_${movieCounter}`).setAttribute("src","css/ImageNotFound.png");
        }
      document.getElementById("movies").innerHTML = output;
    }
    catch(error){
      console.error(error);
      document.getElementById("movies").innerHTML = `<h6> No Content Found!...Try Again </h6>`;
    }
}
